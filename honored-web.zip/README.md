# honored website

This website is to be paired with the discord bot's source code which can be found @ **https://github.com/enlarged/honored-web**

# Setup guide

1. Register a domain
2. Use your registrar to set DNS records to github's
3. Wait for your DNS records to register
